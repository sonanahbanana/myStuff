var buttons = [];
var count;
var buttonRounds;
var randomButton;

var showButtons = true;

var particles = [];
var particles2 = [];

var fireSound;

var playFireSound = false;

// pre loads all the neccessary assets
function preload()
{
    soundFormats('mp3','wav');
    
    buttonImg = loadImage('assets/button.png');
    
    beepSound = loadSound('assets/beep.mp3');
    beepSound.setVolume(0.8);
    
    fireSound = loadSound('assets/fire.wav');
    fireSound.setVolume(2);
}

function setup()
{
	createCanvas(screen.width, screen.height);
    
    // generates a random number between 1 and 5 for the number of buttons
    
    // the number of buttons created on the screen will be the value of randomB
    numButtons = floor(random(1, 5));
    count = 0;
    buttonRounds = 0;
    
    randomButton = floor(random(1, 50));
    
    
    // creates buttons in random locations on the canvas
    for(var i = 0; i < numButtons; i++)
    {
        // creates random locations for buttons' x and y positions
        buttons.push({pos: createVector(random(50, width - 50), random(50, height - 50)), state: false});
        
        // button array, makes the buttons an object and pushes each button x and y pos into the array
    }
}

function draw()
{
    count = 0;
    
    
    if(showButtons == true)
    {
        background(255)
        if(buttons.length > 0)
        {
            for (var i = 0; i < buttons.length; i++)
            {
                image(buttonImg, buttons[i].pos.x, buttons[i].pos.y, 80, 80);
            
                if (buttons[i].state)
                {
                count++; 
                }
            }
            
            if (count == buttons.length)
            {
                buttons = [];
                numButtons = floor(random(1, 5));
                for(var i = 0; i < numButtons; i++)
                {
                    buttons.push({pos: createVector(random(50, 400), random(50, 500)), state: false});
                }
            
                console.log("random button = " + randomButton)
                console.log("count = " + count);
                console.log("button rounds = " + buttonRounds);
            }
        }    
    }
    
    
    if(randomButton == buttonRounds)
    {
        showButtons = false;
//        textSize(15);
//        text("FIIIIIIRRRREEEEEEEEE", 100, 100);
        background(30, 60);
        
       if(!playFireSound)
        {
            playFireSound = true;
            fireSound.loop();
            console.log("play fire");
        }
  
        for(var i = 0; i < 10; i++) 
        {
            particles.push(new Particle());
        }
    
        for(var i = 0; i < 10; i++) 
        {
            particles2.push(new Particle());
        }
    
        for(var i = particles.length - 1; i >= 0; i--) 
        {
            particles[i].update();
            particles[i].show(random(200,240), random(50, 150), 10);
            if (particles[i].finished()) 
            {
                particles.splice(i, 1);
            }
        }
    
        for (var i = particles2.length - 1; i >= 0; i--) 
        {
            particles2[i].update();
            particles2[i].show(random(180, 200), 50, 10);
            if(particles2[i].finished()) 
            {
                particles2.splice(i, 1);
            }
        }
    }
}

function Particle() 
{
    this.x = random(10, width-10);
    this.y = height;
    this.vx = random(-1, 1);
    this.vy = random(-7, -1);
    this.alpha = 255;
    this.diam = 20;

    this.finished = function() 
    {
        return this.alpha < 0;
    }

    this.update = function() 
    {  
        this.x += this.vx;
        this.y += this.vy;
        this.alpha -= random(3, 2);
        this.d -= random(0.05, 0.1);
    }

    this.show = function(r, g, b) 
    {
        noStroke();
        fill(r, g, b, this.alpha);
        ellipse(this.x, this.y, this.diam);
    }
}

function mousePressed()
{
    for(var i = 0; i < buttons.length; i++)
    {
        // checks the between mouse x and y positions and the button x and y positions
        var distance = dist(mouseX, mouseY, buttons[i].pos.x + 30, buttons[i].pos.y + 30);
        
        // if the mouse presses on the button (mouse is between the button x and y pos with an additional 45 pixels), a beeping sound will be made
        if(distance < 25)
        {
            // when one of the buttons is pressed, the boolean buttonPressed is set to true
            buttons[i].state = true;
            //console.log("button pressed");
            beepSound.play();
            if(buttons[i].state == true)
            {
                buttonRounds++;
            }
        }
    }
}
