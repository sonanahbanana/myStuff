// button mode transitioning into fire mode
var buttons = [];
var count;
var buttonRounds;
var randomButton;
var showButtons = true;

var particles = [];
var particles2 = [];
var fireSound;
var playFireSound = false;

// pre loads all the neccessary assets
function preload()
{
    soundFormats('mp3','wav');
    
    // button mode
    buttonImg = loadImage('assets/button.png');
    beepSound = loadSound('assets/beep.mp3');
    beepSound.setVolume(0.8);
    
    // fire mode
    fireSound = loadSound('assets/fire.wav');
    fireSound.setVolume(2);
}

function setup()
{
	createCanvas(screen.width, screen.height);
    
     // the number of buttons created on the screen will be between 1 and 5
    numButtons = floor(random(1, 5));
    // counter for how many buttons have been pressed
    count = 0;
    // how many buttons in total have been pressed
    buttonRounds = 0;
    
    // randomly picked button between 1 and 30 to end the mode
    randomButton = floor(random(1, 25));
    
    
    // creates buttons in random locations on the canvas
    for(var i = 0; i < numButtons; i++)
    {
        // creates random locations for buttons' x and y positions
        buttons.push({pos: createVector(random(50, width - 50), random(50, height - 50)), state: false});
    }
}

function draw()
{
    // counter starts at 0 at the beginning of every draw loop (resetting the counter after the if statment is finished)
    count = 0;
    
    // if the button mode is meant to be shown
    if(showButtons == true)
    {
        background(255)
        if(buttons.length > 0)
        {
            // draws every instance of the button asset in random x and y positions
            for (var i = 0; i < buttons.length; i++)
            {
                image(buttonImg, buttons[i].pos.x, buttons[i].pos.y, 80, 80);
            
                // if the button state is true (has been pressed), add 1 to the counter
                if (buttons[i].state)
                {
                count++; 
                }
            }
            
            // if the counter value is the same as the total number of buttons in that round...
            if (count == buttons.length)
            {
                // reset the button array value to a new value between 1 and 5
                buttons = [];
                numButtons = floor(random(1, 5));
                // pushes the new button values into the array
                for(var i = 0; i < numButtons; i++)
                {
                    buttons.push({pos: createVector(random(50, width - 50), random(50, height - 50)), state: false});
                }
            
                console.log("random button = " + randomButton)
                console.log("count = " + count);
                console.log("button rounds = " + buttonRounds);
            }
        }    
    }
    
    // if the randomly chosen button value is equal to the total number of buttons pressed on all rounds...
    if(randomButton == buttonRounds)
    {
        // stop showing the buttons
        showButtons = false;
        
        // grey background
        background(30, 60);
        
        // if the fire sound isn't playing 
        if(!playFireSound)
        {
            // playFireSound to true
            playFireSound = true;
            // loop the fire sound
            fireSound.loop();
            console.log("play fire");
        }
  
        // pushes 10 particle objects onto the array particles (colour scheme 1)
        for(var i = 0; i < 10; i++) 
        {
            particles.push(new Particle());
        }
        
        // pushes 10 particle objects onto the array particles2 (colour scheme 2)
        for(var i = 0; i < 10; i++) 
        {
            particles2.push(new Particle());
        }
    
        // works from the back of the array
        for(var i = particles.length - 1; i >= 0; i--) 
        {
            // updates the positions of the particles
            particles[i].update();
            // arguments are for the particles' colour scheme
            particles[i].show(random(200,240), random(50, 150), 10);
            // if the particle is finished (alpha less than 0)...
            if (particles[i].finished()) 
            {
                // it is removed from the array
                particles.splice(i, 1);
            }
        }
    
        // works from the back of the array 
        for (var i = particles2.length - 1; i >= 0; i--) 
        {
            // updates the positions of the particles
            particles2[i].update();
            // arguments are for the particles' colour scheme
            particles2[i].show(random(180, 200), 50, 10);
            // if the particle is finished (alpha less than 0)...
            if(particles2[i].finished()) 
            {
                // it is removed from the array
                particles2.splice(i, 1);
            }
        }
    }
}

// function for the fire particles
function Particle() 
{
    // random starting x position on ther canvas
    this.x = random(10, width-10);
    // starting y position on the bottom of the canvas
    this.y = height;
    // random starting x velocity between -1 and 1 (left or right)
    this.vx = random(-1, 1);
    // random starting y velocity between -7 and -1 (moving upwards)
    this.vy = random(-7, -1);
    // starting alpha value (full colour)
    this.alpha = 255;
    // starting diameter for the particle
    this.diam = 20;

    // function that controls when the particle needs to be removed (finished)
    this.finished = function() 
    {
        // when the alpha value is below 0
        return this.alpha < 0;
    }

    // function that updates the particle
    this.update = function() 
    {  
        // x pos is increased by the x velocity
        this.x += this.vx;
        // y pos is increased by the y velocity
        this.y += this.vy;
        // alpha is decreased by a random number between 3 and 2
        this.alpha -= random(3, 2);
        // diameter is decreased by a random number between 0.05 ans 0.1
        this.diam -= random(0.05, 0.1);
    }

    // function that controls the appearance of the function
    this.show = function(r, g, b) 
    {
        noStroke();
        // parameters allow for the colours to be changed for different arrays
        fill(r, g, b, this.alpha);
        ellipse(this.x, this.y, this.diam);
    }
}

function mousePressed()
{
    // for all the buttons in the buttons array...
    for(var i = 0; i < buttons.length; i++)
    {
        // checks the between mouse x and mouse y positions and the button x and button y positions
        var distance = dist(mouseX, mouseY, buttons[i].pos.x + 30, buttons[i].pos.y + 30);
        
        // if the mouse presses on the button (mouse is between the button x and y pos with an additional 45 pixels), a beeping sound will be made
        if(distance < 25)
        {
            // when one of the buttons is pressed, button state is set to true
            buttons[i].state = true;
            //console.log("button pressed");
            beepSound.play();
            // when a button state is set to true, buttonRounds is increased by 1
            if(buttons[i].state == true)
            {
                buttonRounds++;
            }
        }
    }
}
