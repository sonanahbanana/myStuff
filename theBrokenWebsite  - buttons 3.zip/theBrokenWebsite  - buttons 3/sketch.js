var buttons = [];
var count;
var buttonRounds


// pre loads all the neccessary assets
function preload()
{
    soundFormats('mp3','wav');
    
    buttonImg = loadImage('assets/button.png');
    
    beepSound = loadSound('assets/beep.mp3');
    beepSound.setVolume(0.8);
    
}

function setup()
{
	createCanvas(screen.width, screen.height);
    
    // generates a random number between 1 and 5 for the number of buttons
    
    // the number of buttons created on the screen will be the value of randomB
    numButtons = floor(random(1, 5));
    count = 0;
    
    
    // creates buttons in random locations on the canvas
    for(var i = 0; i < numButtons; i++)
    {
        // creates random locations for buttons' x and y positions
        buttons.push({pos: createVector(random(50, 400), random(50, 500)), state: false});
        
        // button array, makes the buttons an object and pushes each button x and y pos into the array
    }
}

function draw()
{
    background(255)
    count = 0;
    
    if(buttons.length > 0)
    {
        for (var i = 0; i < buttons.length; i++)
        {
            image(buttonImg, buttons[i].pos.x, buttons[i].pos.y, 80, 80);
            
            if (buttons[i].state)
            {
                count++
            }
        }
        if (count == buttons.length)
        {
            buttons = [];
            numButtons = floor(random(1, 5));
            for(var i = 0; i < numButtons; i++)
            {
                buttons.push({pos: createVector(random(50, 400), random(50, 500)), state: false});
            }
        }
    }
}

function mousePressed()
{
    for(var i = 0; i < buttons.length; i++)
    {
        // checks the between mouse x and y positions and the button x and y positions
        var distance = dist(mouseX, mouseY, buttons[i].pos.x + 30, buttons[i].pos.y + 30);
        
        // if the mouse presses on the button (mouse is between the button x and y pos with an additional 45 pixels), a beeping sound will be made
        if(distance < 25)
        {
            // when one of the buttons is pressed, the boolean buttonPressed is set to true
            buttons[i].state = true;
            //console.log("button pressed");
            beepSound.play();
        }
        else
        {
            // otherwise the boolean is set to false
            buttonPressed = false;    
        }
        // if buttonPressed is set to true, add 1 to pressedCounter
    }
}
